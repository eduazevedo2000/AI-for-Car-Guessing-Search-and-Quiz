import React, { useState, useEffect } from 'react';
import {
  IonPage,
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonInput,
  IonButton,
  IonFooter,
  IonCard,
  IonCardHeader,
  IonCardTitle,
  IonCardContent,
  IonImg,
} from '@ionic/react';
import './Search.css'

const CarInputPage: React.FC = () => {
  const [marca, setMarca] = useState<string>('');
  const [modelo, setModelo] = useState<string>('');
  const [ano, setAno] = useState<string>('');
  const [randomImages, setRandomImages] = useState<string[]>([]);
  const [warningMessage, setWarningMessage] = useState<string>('');
  const [validYears, setValidYears] = useState<string>('');

  useEffect(() => {
    if (marca && modelo && ano) {
      fetch('http://45.65.114.202:8880/search', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          make: marca,
          model: modelo,
          year: ano,
        }),
      })
        .then((response) => response.json())
        .then((data) => {
          if (data != null && data.status === 'warning') {
            setWarningMessage(data.message);
            setValidYears(data.data.valid_years_text);
          } else {
            const images = data.data.images;
            setRandomImages(images);
            setWarningMessage(''); // Limpa a mensagem de aviso se houver imagens válidas
          }
        })
        .catch((error) => {
          console.error('Erro ao obter dados da API:', error);
        });
    }
  }, [marca, modelo, ano]); // A função useEffect será chamada sempre que marca, modelo ou ano mudarem

  const handleSubmit = () => {
    // Aqui podes fazer algo com a marca, modelo e ano, como enviar para um servidor
    console.log('Marca:', marca);
    console.log('Modelo:', modelo);
    console.log('Ano:', ano);
  };

  return (
    <IonPage>
      <IonContent className="backgroundImageSearch" fullscreen>
      <IonCard className='cardPrincipalSearch'>
      <IonCardTitle className='cardTitlePrincipal'>
       Pesquisa qualquer carro que tenhas interesse e eu mostro-te as fotos
      </IonCardTitle>
        <IonInput
          placeholder="Marca do carro"
          value={marca}
          onIonChange={(e) => setMarca(e.detail.value!)}
          style={{ color: 'white' }}
        ></IonInput>
        <IonInput
          placeholder="Modelo do carro"
          value={modelo}
          onIonChange={(e) => setModelo(e.detail.value!)}
          style={{ color: 'white' }}
        ></IonInput>
        <IonInput
          placeholder="Ano do carro"
          value={ano}
          type="number"
          onIonChange={(e) => setAno(e.detail.value!)}
          style={{ color: 'white' }}
        ></IonInput>

        <IonButton expand="full" onClick={handleSubmit}>
          Submeter
        </IonButton>
      </IonCard>
        {warningMessage && (
          <IonCard>
            <IonCardHeader>
              <IonCardTitle>Aviso</IonCardTitle>
            </IonCardHeader>
            <IonCardContent>{warningMessage} Anos específicos: {validYears}</IonCardContent>
          </IonCard>
        )}
        {randomImages.length > 0 && (
          <IonCard>
            <IonCardContent>
              {randomImages.map((imageUrl, index) => (
                <IonImg key={index} src={imageUrl} alt={`Imagem ${index + 1}`} />
              ))}
            </IonCardContent>
          </IonCard>
        )}
      </IonContent>
    </IonPage>
  );
};

export default CarInputPage;