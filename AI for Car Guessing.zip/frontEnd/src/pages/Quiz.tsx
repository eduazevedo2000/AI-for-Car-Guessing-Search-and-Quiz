import React, { useState, useEffect } from 'react';
import { IonContent, IonHeader, IonPage, IonTitle, IonToolbar, IonImg, IonButton, IonLabel, IonInput, IonAlert, IonCard, IonCardContent, IonCardHeader, IonCardTitle } from '@ionic/react';
import axios from 'axios';
import { card } from 'ionicons/icons';
import './Quiz.css'

const API_URL = 'http://45.65.114.202:8880/send_random_car_info';

const Quiz: React.FC = () => {
  const [carData, setCarData] = useState<any>(null);
  const [userGuess, setUserGuess] = useState({ marca: '' , modelo: '' });
  const [showAlert, setShowAlert] = useState(false);

  useEffect(() => {
    fetchCarData();
  }, []);

  const fetchCarData = async () => {
    try {
      const response = await axios.get(API_URL);
      console.log('API Response:', response.data.data); // Log the response
      setCarData(response.data.data);
    } catch (error) {
      console.error('Error fetching car data', error);
    }
  };
  
  const resetGame = () => {
    setCarData(null);
    setUserGuess({ marca: '', modelo: '' });
    setShowAlert(false);
  };
  useEffect(() => {
    if (carData === null) {
      fetchCarData(); // Fetch new car data after resetting
    }
  }, [carData]);

  const handleGuess = () => {
      const correctMake = carData?.make.toLowerCase() === userGuess.marca.toLowerCase();
      const correctModel = carData?.model.toLowerCase() === userGuess.modelo.toLowerCase();
  
      if (correctMake && correctModel) {
        setShowAlert(true);
      } else {
        setShowAlert(false);
        console.log(carData.make);
        console.log(carData.model);
      }
  };

  return (
    <IonPage>
      <IonContent fullscreen className='backgroundImage'>
        <IonCard className='cardTotal'>
      <IonCardTitle className='cardTitlePrincipal'>
        Tenta adivinhar a marca e o modelo do carro cujas imagens são mostradas 😁
      </IonCardTitle>
        {carData && (
          <>
            <IonCard className='cardTotal1'>
      <IonCardHeader>
        <IonCardTitle color={'dark'}>Qual é este carro?</IonCardTitle>
      </IonCardHeader>
      <IonCardContent>
        <IonImg src={carData.images[0]} />
        <IonImg src={carData.images[1]} />
        <IonImg src={carData.images[2]} />
        <IonImg src={carData.images[3]} />
        <IonImg src={carData.images[4]} />
      </IonCardContent>
    </IonCard>
            <IonLabel color={'light'}>Marca:</IonLabel>
            <IonInput
              value={userGuess.marca}
              placeholder="Escreva aqui"
              onIonChange={(e) => setUserGuess({ ...userGuess, marca: e.detail.value! })}
              style={{ color: 'black' }}
            />
            <IonLabel color={'light'}>Modelo:</IonLabel>
            <IonInput
              value={userGuess.modelo}
              placeholder="Escreva aqui"
              onIonChange={(e) => setUserGuess({ ...userGuess, modelo: e.detail.value! })}
              style={{ color: 'black' }}
            />
            <IonButton expand="full" onClick={handleGuess}>
              Submeter resposta
            </IonButton>
          </>
        )}
        <br />
        <IonAlert
          isOpen={showAlert}
          onDidDismiss={resetGame}
          header="Parabéns!"
          message={`Acertou a adivinha! É um ${carData?.make} ${carData?.model}.`}
          buttons={['Voltar a jogar']}
        />
        </IonCard>
      </IonContent>
    </IonPage>
  );
};

export default Quiz;