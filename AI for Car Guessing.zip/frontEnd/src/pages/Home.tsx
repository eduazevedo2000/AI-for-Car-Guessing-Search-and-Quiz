import React, { useRef, useState } from 'react';
import {
  IonContent,
  IonPage,
  IonCard,
  IonCardHeader,
  IonCardTitle,
  IonCardContent,
  IonButton,
  IonActionSheet,
  IonFab,
  IonFabButton,
  IonIcon,
  IonFooter,
  IonTitle,
  IonToolbar,
  IonModal,
  IonHeader,
} from '@ionic/react';
import axios from 'axios';
import './Home.css'
import { colorFill, imagesOutline } from 'ionicons/icons';

const Home: React.FC = () => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [carInfo, setCarInfo] = useState<string | null>(null);
  const [imageModalSrc, setImageModalSrc] = useState<string | null>(null);

  const openModal = (imageSrc: string) => {
    setImageModalSrc(imageSrc);
  };

  const closeModal = () => {
    setImageModalSrc(null);
    setCarInfo(null);
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      sendFileToApi(file);
    }
  };

  const sendFileToApi = (file: File) => {
    const formData = new FormData();
    formData.append('file', file);

    axios.post('http://45.65.114.202:8880/get_name_from_ai', formData)
      .then(response => {
        //Resposta do API

        setCarInfo(response.data.message);
        openModal(URL.createObjectURL(file));
        console.log('Message:', response.data.message);
      })
      .catch(error => {
        console.error('Error uploading file to API', error);
      });
  };

  return (
    <IonPage>
      <IonContent fullscreen className='backgroundImage' >
          <IonTitle class='titulo'>Car AI</IonTitle>
          <IonCard className='transparente'>
            <IonTitle className='letra'>
              Bem-vindo ao Car AI
            </IonTitle>
            <br />
            <IonCardContent class='letra'>
              Sou uma inteligência artificial que permite saberes para que carro estás a olhar, fornecendo-te a marca e o modelo. <br />
              Também possuo uma vasta galeria de automóveis, galeria essa que tu podes aceder clicando na opção "Search". <br />
              Por fim tenho um pequeno desafio para ti, que podes encontrar na última opção da TabBar <br />
              Experimenta as minhas habilidades clicando no botão abaixo 👇
            </IonCardContent>
            <IonButton className='buttonLoad' id='open-action-sheet' color="dark" shape='round'>
            <IonIcon slot='start' icon={imagesOutline}>
              </IonIcon>Carregar fotografias</IonButton>
          <IonActionSheet
            trigger="open-action-sheet"
            header="Escolha uma opção"
            buttons={[
              {
                text: 'Galeria',
                role: 'destructive',
                handler: () => {
                  const fileInput = fileInputRef.current;
                  if (fileInput) {
                    fileInput.click();
                  }
                },
              },
              {
                text: 'Cancelar',
                role: 'cancel',
              },
            ]}
          ></IonActionSheet>
          <input
            type="file"
            accept="image/*"
            ref={fileInputRef}
            style={{ display: 'none' }}
            onChange={handleFileChange}
          />
          </IonCard>
        {carInfo && (
        <IonModal isOpen={imageModalSrc !== null} onDidDismiss={closeModal}>
          <IonHeader>
            <IonTitle>Informações sobre a sua Fotografia</IonTitle>
          </IonHeader>
          <IonContent>
            {imageModalSrc !== null && (
              <>
                <img alt="Car" src={imageModalSrc} />
                <IonCardContent>
                  {carInfo}
                </IonCardContent>
              </>
            )}
          </IonContent>
        </IonModal>
      )}
        <br />
      </IonContent>
    </IonPage>
  );
};

export default Home;